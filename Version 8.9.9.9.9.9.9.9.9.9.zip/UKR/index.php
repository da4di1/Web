<?php

session_start();

$lang = '';
if(isset($_GET['lang'])){
    $lang = $_GET['lang'];
    setcookie("LanguageCookie", $lang, time() + 15380000);
    }
 
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Bangtsar</title>
        <link rel="stylesheet" href="./Site.css" type="text/css"/>
        <link href="https://uk.allfont.net/allfont.css?fonts=lobster" rel="stylesheet" type="text/css" />
        <link href="https://uk.allfont.net/allfont.css?fonts=rodchenkoctt" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css2?family=Comfortaa&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@500&display=swap" rel="stylesheet">
        <script type="text/javascript" 
            src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js">
        </script>
	    <script type="text/javascript">
            $(document).ready(function () {
			
		    $('#ajaxBtn1').click(function(){
			    $.ajax('topfirstajax.html',   // request url
			    {            
				    success: function (data, status, xhr) {    // success callback function
						    $('#ajax1').html(data);
				    }
			    });
		    });

            });
        </script>

        <script>
            $(document).ready(function () {
			
		    $('#ajaxBtn2').click(function(){
			    $.ajax('statictics.html',   // request url
			    {            
				    success: function (data, status, xhr) {    // success callback function
						    $('#ajax2').html(data);
				    }
			    });
		    });

            });
        </script>

        <script>
            $(document).ready(function () {
            
            $('#ajaxBtn3').click(function(){
                $.ajax('whywe.html',   // request url
                {            
                    success: function (data, status, xhr) {    // success callback function
                            $('#ajax3').html(data);
                    }
                });
            });

            });
        </script>

        <script>
            $().ready(function() {
            $("#ajaxBtn1").click(function () {
                $(this).hide();
                
            });
            });
        </script>

        <script>
            $().ready(function() {
            $("#ajaxBtn2").click(function () {
                $(this).hide();
            });
            });
        </script>

        <script>
            $().ready(function() {
            $("#ajaxBtn3").click(function () {
                $(this).hide();
            });
            });
        </script>
    </head>
    <body>
        <div class="header">
            <div class="container">
                <div class="header_inner">
                    <a class="logo" href="index.php">Bangtsar.com</a>
                    <div class="login">
                        <?php
                        if (isset($_SESSION['user'])){
                            echo '<span class="log-nickname"> ' . $_SESSION['user']['username'] . ' </span>';
                            echo '<a class="log-link" href = "inc/logout.php">Вихід</a>';
                        }else{
                            echo '<a class="log-link" href = "Login.php">Вхід</a>';
                            echo '<a class="log-link" href = "Registration.php">Реєстрація</a>';
                        }
                        unset($_SESSION['message']);
                        ?>
                    </div>
                    <nav class="nav">
                        <div class="nav-link courses_button">Каталог курсів</div>
                        <ul hidden class="courses_list">
                            <li><a href = "./tabs/catalogue/csharp.php" class="courses_link">C#</a></li>
                            <li><a href = "./tabs/catalogue/cpluses.php" class="courses_link">C++</a></li>
                            <li><a href = "./tabs/catalogue/java.php" class="courses_link">Java</a></li>
                            <li><a href = "./tabs/catalogue/python.php" class="courses_link">Python</a></li>
                            <li><a href = "./tabs/catalogue/js.php" class="courses_link">JavaScript</a></li>
                        </ul>
                        <a class="nav-link" href = "./tabs/quiz/quiz.php">Підбери курс</a>
                        <a class="nav-link" href = "./tabs/answers/Answers.php">Відповіді на питання</a>
                        <a class="nav-link" href = "./tabs/activity rating/rating.php">Рейтинг активності</a>
                    </nav>
                </div>
                <!---->
                <div class="languages">
                    <div class="lang_button">
                        <a href="../UKR/index.php?lang=UKR" width="20px"><img src="./images/Flag_of_Ukraine.png" width="20px" 
                        border="0" alt="UKR"></a>
                    </div>
                    <div class="lang_button">
                    <a href="../DEU/index.php?lang=DEU" width="20px"><img src="./images/Flag_of_Germany.png" width="20px" 
                        border="0" alt="DEU"></a>
                    </div>
                    <div class="lang_button">
                        <a href="../JPN/index.php?lang=JPN" width="20px"><img src="./images/Flag_of_Japan.png" width="20px" 
                        border="0" alt="JPN"></a>
                    </div>
                </div>
                <!---->
            </div>
        </div>

        <div class="intro">
            <div class="container">
                <div class="intro_inner">
                    <h1 class="intro_title">Сайт для вивчення мов програмування</h1>
                    <h3 class="intro_subtitle">За допомогою нашого сайту ви легко зможете дізнатися, яка мова програмування є ідеальною саме для вас! 
                        А після проходження тесту перед вами з'явиться перелік курсів, щоб ви не гаяли часу та одразу почали навчання. Вивчайте більше мов, проходьте більше курсів і
                        підіймайтесь вверх в рейтингу успішності. Покажіть усім, хто тут справжній поліглот в програмуванні! 
                    </h3>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; margin-right:660px;">
        <input type="submit" id='ajaxBtn3' value="Чому ми?" style="margin-left: 680px"/>
                    </div>
	    <div id="ajax3">

        </div>
        <div style="text-align: center; margin-right:660px;">
        <input type="submit" id='ajaxBtn1' value="Дізнатись про ТОП-1 курс" style="margin-left: 680px"/>
        </div>
	    <div id="ajax1">

        </div>
        <div style="text-align: center; margin-right:670px;">
        <input type="submit" id='ajaxBtn2' value="Переглянути статистику" style="margin-left: 680px"/>
        </div>
	    <div id="ajax2">
</div>
        
        <div class="fifth_slide">
            <div class="container">
                <div class=fifth_slide_inner>
                    <h1 class="fifth_slide_title">Зв'яжіться з нами</h1>
                    <p class="fifth_slide_subtitle">Якщо у вас виникли питання, ви завжди можете написати і ми вам відповімо протягом години!</p>
                    <form method="post" autocomplete="off">
                        <input type=text name="name" id="full_name" placeholder="Your full name" required><br>
                        <input type=text name="email" id="email" placeholder="E-mail" required><br>
                        <input type=text name="question" id="number"placeholder="Your question" required>
                        <p class="sure_text"><input type="checkbox" id = "PersonalDataCheckbox" onclick="uncheckAlert()" name="Personal data" required> 
                        Я погоджуюсь на обробку особистих данних</p>
                        <input type="submit" id="ContactsSubmitButton" value="Надіслати">
                    </form>
                    <?php
                    if(isset($_POST['name'])){
                    $Qname=$_POST['name'];
                    $Qemail=$_POST['email'];
                    $Qquestion=$_POST['question'];
                    $name = time() . "question.txt";
                    $fp = fopen($name, 'a');
                    rename($name, "../feedback/$name");
                    fwrite($fp, $Qname); fwrite($fp, "\n"); 
                    fwrite($fp, $Qemail); fwrite($fp, "\n"); 
                    fwrite($fp, $Qquestion); fwrite($fp, "\n"); 
                    fclose($fp);
                    }
                    ?>
                    <div class="ya-share2" data-curtain data-size="l" data-shape="round" data-lang="en" data-color-scheme="blackwhite" data-services="facebook,telegram,twitter,pinterest"></div>
                </div>
            </div>
        </div>
<!-----><?if (isset($_COOKIE["LanguageCookie"])) echo "Language: " . $_COOKIE["LanguageCookie"] . "<br>";?>        
        <script src="Site.js"></script>
    </body>
</html>